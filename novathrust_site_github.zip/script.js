// Placeholder for future features like order form or kit selector
console.log('NOVATHRUST site loaded');
